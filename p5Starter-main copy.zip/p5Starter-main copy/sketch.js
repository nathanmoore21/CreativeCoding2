let data01 = [{
        name: "Oranges",
        total: 23
    },
    {
        name: "Bananas",
        total: 34
    },
    {
        name: "Pears",
        total: 23
    },
    {
        name: "Apples",
        total: 18
    }
];
let data02 = [{
        name: "Oranges",
        total: 23
    },
    {
        name: "Bananas",
        total: 34
    },
    {
        name: "Bananas",
        total: 32
    },
    {
        name: "Pears",
        total: 23
    },
    {
        name: "Apples",
        total: 18
    }
];
let data03 = [
    // { name: "Oranges", 
    //     total = [
    //         { tesco: 15, lidl:10, aldi:10 }
    //     ]
    // },
    {
        name: "Bananas",
        total: 34
    },
    {
        name: "Pears",
        total: 23
    },
    {
        name: "Apples",
        total: 18
    }
];
let data04 = [{
        name: "Tesco",
        total: 34
    },
    {
        name: "Aldi",
        total: 23
    },
    {
        name: "Lidi",
        total: 18,
    },
    {
        name: "Dunnes",
        total: 19,
    }
];
// let data05 = [{
//     name: "Tesco",
//     total: 34
// },
// {
//     name: "Aldi",
//     total: 23
// },
// {
//     name: "Lidi",
//     total: 18,
// },
// {
//     name: "Dunnes",
//     total: 19,
// }
// ];
// let data06 = [{
//     name: "Tesco",
//     total: 34
// },
// {
//     name: "Aldi",
//     total: 23
// },
// {
//     name: "Lidi",
//     total: 18,
// },
// {
//     name: "Dunnes",
//     total: 19,
// }
// ];

let chart01;
let chart02;
let chart03;
let chart04;
// let chart05;
// let chart06;

function setup() {
    createCanvas(800, 800);

    chart01 = new BarChart(data01)
    chart01.chartWidth = 200;
    chart01.chartHeight = 200;
    chart01.posX = 100;
    chart01.posY = 300;

    chart02 = new HorizontalBarChart(data02)
    chart02.chartWidth = 300;
    chart02.chartHeight = 200;
    chart02.posX = 400;
    chart02.posY = 300;

    chart03 = new StackChart(data03)
    chart03.chartWidth = 200;
    chart03.chartHeight = 200;
    chart03.posX = 100;
    chart03.posY = 650;

    chart04 = new BarChart_(data04)
    chart04.chartWidth = 200;
    chart04.chartHeight = 200;
    chart04.posX = 400;
    chart04.posY = 650;

    // chart05 = new BarChart_(data05)
    // chart05.chartWidth = 200;
    // chart05.chartHeight = 200;
    // chart05.posX = 100;
    // chart05.posY = 1000;

    // chart06 = new BarChart_(data05)
    // chart06.chartWidth = 200;
    // chart06.chartHeight = 200;
    // chart06.posX = 400;
    // chart06.posY = 1000;
}

function draw() {
    background(50);
    chart01.updateValues();
    chart01.render();
    chart02.updateValues();
    chart02.render();
    chart03.updateValues();
    chart03.render();
    chart04.updateValues();
    chart04.render();
    // chart05.updateValues();
    // chart05.render();
    // chart06.updateValues();
    // chart06.render();
}